import 'package:flutter/material.dart';

//Define Statefuak Widget class here

class NewFileState extends State<NewFile> {
  TextEditingController newSentence = TextEditingController();
  String sentence = '';
  bool flag = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: const Color(0xff0140a28),
        leading: const Icon(Icons.menu),
        title: const Text("To Do List"),
      ),
      body: Container(
        width: double.infinity,
        child: Column(
          children: [
            const SizedBox(
              height: 20,
            ),
            Container(
              width: 325,
              child: TextFormField(
                controller: newSentence,
                decoration: const InputDecoration(
                  labelText: "New Sentence",
                  labelStyle: TextStyle(color: Color(0xff321a70)),
                  border: OutlineInputBorder(),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Color(0xff321a70))),
                  prefixIcon: Icon(Icons.edit),
                  prefixIconColor: Color(0xff321a70),
                ),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            // Add Material Button Code here
            const SizedBox(
              height: 20,
            ),
            //Add here the row that will be added once we write the task and click submit(Using Set State function)
          ],
        ),
      ),
    );
  }
}
